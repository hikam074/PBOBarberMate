--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PBO_BarberMate";
--
-- Name: PBO_BarberMate; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "PBO_BarberMate" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE "PBO_BarberMate" OWNER TO postgres;

\connect "PBO_BarberMate"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: akun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.akun (
    id_akun integer NOT NULL,
    nama_akun character varying(64) NOT NULL,
    email character varying(128) NOT NULL,
    password character varying(64) NOT NULL,
    akun_role_id integer NOT NULL
);


ALTER TABLE public.akun OWNER TO postgres;

--
-- Name: akun_id_akun_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.akun_id_akun_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.akun_id_akun_seq OWNER TO postgres;

--
-- Name: akun_id_akun_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.akun_id_akun_seq OWNED BY public.akun.id_akun;


--
-- Name: akun_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.akun_role (
    id_role integer NOT NULL,
    nama_role character varying(16)
);


ALTER TABLE public.akun_role OWNER TO postgres;

--
-- Name: akun_role_id_role_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.akun_role_id_role_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.akun_role_id_role_seq OWNER TO postgres;

--
-- Name: akun_role_id_role_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.akun_role_id_role_seq OWNED BY public.akun_role.id_role;


--
-- Name: detail_hari; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_hari (
    id_hari integer NOT NULL,
    nama_hari character varying(16) NOT NULL
);


ALTER TABLE public.detail_hari OWNER TO postgres;

--
-- Name: detail_hari_id_hari_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detail_hari_id_hari_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.detail_hari_id_hari_seq OWNER TO postgres;

--
-- Name: detail_hari_id_hari_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detail_hari_id_hari_seq OWNED BY public.detail_hari.id_hari;


--
-- Name: histori_pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.histori_pembayaran (
    id_histori_pembayaran integer NOT NULL,
    harga integer NOT NULL,
    id_reservasi integer NOT NULL,
    id_status_perubahan integer NOT NULL
);


ALTER TABLE public.histori_pembayaran OWNER TO postgres;

--
-- Name: histori_pembayaran_id_histori_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.histori_pembayaran_id_histori_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.histori_pembayaran_id_histori_pembayaran_seq OWNER TO postgres;

--
-- Name: histori_pembayaran_id_histori_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.histori_pembayaran_id_histori_pembayaran_seq OWNED BY public.histori_pembayaran.id_histori_pembayaran;


--
-- Name: histori_perubahan_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.histori_perubahan_status (
    id_status_perubahan integer NOT NULL,
    nama_status_perubahan character varying(32) NOT NULL
);


ALTER TABLE public.histori_perubahan_status OWNER TO postgres;

--
-- Name: histori_perubahan_status_id_status_perubahan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.histori_perubahan_status_id_status_perubahan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.histori_perubahan_status_id_status_perubahan_seq OWNER TO postgres;

--
-- Name: histori_perubahan_status_id_status_perubahan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.histori_perubahan_status_id_status_perubahan_seq OWNED BY public.histori_perubahan_status.id_status_perubahan;


--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventaris (
    id_barang integer NOT NULL,
    nama_barang character varying(64) NOT NULL,
    jumlah_barang integer NOT NULL
);


ALTER TABLE public.inventaris OWNER TO postgres;

--
-- Name: inventaris_id_barang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventaris_id_barang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventaris_id_barang_seq OWNER TO postgres;

--
-- Name: inventaris_id_barang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventaris_id_barang_seq OWNED BY public.inventaris.id_barang;


--
-- Name: layanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.layanan (
    id_layanan integer NOT NULL,
    nama_layanan character varying(64) NOT NULL,
    harga integer NOT NULL
);


ALTER TABLE public.layanan OWNER TO postgres;

--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.layanan_id_layanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.layanan_id_layanan_seq OWNER TO postgres;

--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.layanan_id_layanan_seq OWNED BY public.layanan.id_layanan;


--
-- Name: metode_pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metode_pembayaran (
    id_metode_pembayaran integer NOT NULL,
    nama_metode_pembayaran character varying(32) NOT NULL
);


ALTER TABLE public.metode_pembayaran OWNER TO postgres;

--
-- Name: metode_pembayaran_id_metode_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metode_pembayaran_id_metode_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.metode_pembayaran_id_metode_pembayaran_seq OWNER TO postgres;

--
-- Name: metode_pembayaran_id_metode_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metode_pembayaran_id_metode_pembayaran_seq OWNED BY public.metode_pembayaran.id_metode_pembayaran;


--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pembayaran (
    id_pembayaran integer NOT NULL,
    id_reservasi integer,
    harga integer NOT NULL,
    id_metode_pembayaran integer
);


ALTER TABLE public.pembayaran OWNER TO postgres;

--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pembayaran_id_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pembayaran_id_pembayaran_seq OWNER TO postgres;

--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pembayaran_id_pembayaran_seq OWNED BY public.pembayaran.id_pembayaran;


--
-- Name: presensi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presensi (
    id_presensi integer NOT NULL,
    id_akun integer NOT NULL,
    id_shift integer NOT NULL,
    waktu_presensi timestamp without time zone DEFAULT now()
);


ALTER TABLE public.presensi OWNER TO postgres;

--
-- Name: presensi_id_presensi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presensi_id_presensi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.presensi_id_presensi_seq OWNER TO postgres;

--
-- Name: presensi_id_presensi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presensi_id_presensi_seq OWNED BY public.presensi.id_presensi;


--
-- Name: reservasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservasi (
    id_reservasi integer NOT NULL,
    tanggal date NOT NULL,
    waktu time without time zone NOT NULL,
    id_akun integer NOT NULL,
    id_layanan integer NOT NULL,
    id_status_reservasi integer NOT NULL
);


ALTER TABLE public.reservasi OWNER TO postgres;

--
-- Name: reservasi_id_reservasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reservasi_id_reservasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reservasi_id_reservasi_seq OWNER TO postgres;

--
-- Name: reservasi_id_reservasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reservasi_id_reservasi_seq OWNED BY public.reservasi.id_reservasi;


--
-- Name: reservasi_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservasi_status (
    id_status_reservasi integer NOT NULL,
    nama_status_reservasi character varying(32)
);


ALTER TABLE public.reservasi_status OWNER TO postgres;

--
-- Name: reservasi_status_id_status_reservasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reservasi_status_id_status_reservasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reservasi_status_id_status_reservasi_seq OWNER TO postgres;

--
-- Name: reservasi_status_id_status_reservasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reservasi_status_id_status_reservasi_seq OWNED BY public.reservasi_status.id_status_reservasi;


--
-- Name: shift_karyawan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift_karyawan (
    id_shift integer NOT NULL,
    id_akun integer NOT NULL,
    id_hari integer NOT NULL
);


ALTER TABLE public.shift_karyawan OWNER TO postgres;

--
-- Name: shift_karyawan_id_shift_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shift_karyawan_id_shift_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shift_karyawan_id_shift_seq OWNER TO postgres;

--
-- Name: shift_karyawan_id_shift_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shift_karyawan_id_shift_seq OWNED BY public.shift_karyawan.id_shift;


--
-- Name: akun id_akun; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.akun ALTER COLUMN id_akun SET DEFAULT nextval('public.akun_id_akun_seq'::regclass);


--
-- Name: akun_role id_role; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.akun_role ALTER COLUMN id_role SET DEFAULT nextval('public.akun_role_id_role_seq'::regclass);


--
-- Name: detail_hari id_hari; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_hari ALTER COLUMN id_hari SET DEFAULT nextval('public.detail_hari_id_hari_seq'::regclass);


--
-- Name: histori_pembayaran id_histori_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_pembayaran ALTER COLUMN id_histori_pembayaran SET DEFAULT nextval('public.histori_pembayaran_id_histori_pembayaran_seq'::regclass);


--
-- Name: histori_perubahan_status id_status_perubahan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_perubahan_status ALTER COLUMN id_status_perubahan SET DEFAULT nextval('public.histori_perubahan_status_id_status_perubahan_seq'::regclass);


--
-- Name: inventaris id_barang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventaris ALTER COLUMN id_barang SET DEFAULT nextval('public.inventaris_id_barang_seq'::regclass);


--
-- Name: layanan id_layanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.layanan ALTER COLUMN id_layanan SET DEFAULT nextval('public.layanan_id_layanan_seq'::regclass);


--
-- Name: metode_pembayaran id_metode_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metode_pembayaran ALTER COLUMN id_metode_pembayaran SET DEFAULT nextval('public.metode_pembayaran_id_metode_pembayaran_seq'::regclass);


--
-- Name: pembayaran id_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran ALTER COLUMN id_pembayaran SET DEFAULT nextval('public.pembayaran_id_pembayaran_seq'::regclass);


--
-- Name: presensi id_presensi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensi ALTER COLUMN id_presensi SET DEFAULT nextval('public.presensi_id_presensi_seq'::regclass);


--
-- Name: reservasi id_reservasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi ALTER COLUMN id_reservasi SET DEFAULT nextval('public.reservasi_id_reservasi_seq'::regclass);


--
-- Name: reservasi_status id_status_reservasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi_status ALTER COLUMN id_status_reservasi SET DEFAULT nextval('public.reservasi_status_id_status_reservasi_seq'::regclass);


--
-- Name: shift_karyawan id_shift; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_karyawan ALTER COLUMN id_shift SET DEFAULT nextval('public.shift_karyawan_id_shift_seq'::regclass);


--
-- Data for Name: akun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.akun (id_akun, nama_akun, email, password, akun_role_id) FROM stdin;
\.
COPY public.akun (id_akun, nama_akun, email, password, akun_role_id) FROM '$$PATH$$/4892.dat';

--
-- Data for Name: akun_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.akun_role (id_role, nama_role) FROM stdin;
\.
COPY public.akun_role (id_role, nama_role) FROM '$$PATH$$/4890.dat';

--
-- Data for Name: detail_hari; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_hari (id_hari, nama_hari) FROM stdin;
\.
COPY public.detail_hari (id_hari, nama_hari) FROM '$$PATH$$/4894.dat';

--
-- Data for Name: histori_pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.histori_pembayaran (id_histori_pembayaran, harga, id_reservasi, id_status_perubahan) FROM stdin;
\.
COPY public.histori_pembayaran (id_histori_pembayaran, harga, id_reservasi, id_status_perubahan) FROM '$$PATH$$/4912.dat';

--
-- Data for Name: histori_perubahan_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.histori_perubahan_status (id_status_perubahan, nama_status_perubahan) FROM stdin;
\.
COPY public.histori_perubahan_status (id_status_perubahan, nama_status_perubahan) FROM '$$PATH$$/4910.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventaris (id_barang, nama_barang, jumlah_barang) FROM stdin;
\.
COPY public.inventaris (id_barang, nama_barang, jumlah_barang) FROM '$$PATH$$/4914.dat';

--
-- Data for Name: layanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.layanan (id_layanan, nama_layanan, harga) FROM stdin;
\.
COPY public.layanan (id_layanan, nama_layanan, harga) FROM '$$PATH$$/4900.dat';

--
-- Data for Name: metode_pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metode_pembayaran (id_metode_pembayaran, nama_metode_pembayaran) FROM stdin;
\.
COPY public.metode_pembayaran (id_metode_pembayaran, nama_metode_pembayaran) FROM '$$PATH$$/4906.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pembayaran (id_pembayaran, id_reservasi, harga, id_metode_pembayaran) FROM stdin;
\.
COPY public.pembayaran (id_pembayaran, id_reservasi, harga, id_metode_pembayaran) FROM '$$PATH$$/4908.dat';

--
-- Data for Name: presensi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presensi (id_presensi, id_akun, id_shift, waktu_presensi) FROM stdin;
\.
COPY public.presensi (id_presensi, id_akun, id_shift, waktu_presensi) FROM '$$PATH$$/4898.dat';

--
-- Data for Name: reservasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservasi (id_reservasi, tanggal, waktu, id_akun, id_layanan, id_status_reservasi) FROM stdin;
\.
COPY public.reservasi (id_reservasi, tanggal, waktu, id_akun, id_layanan, id_status_reservasi) FROM '$$PATH$$/4904.dat';

--
-- Data for Name: reservasi_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservasi_status (id_status_reservasi, nama_status_reservasi) FROM stdin;
\.
COPY public.reservasi_status (id_status_reservasi, nama_status_reservasi) FROM '$$PATH$$/4902.dat';

--
-- Data for Name: shift_karyawan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift_karyawan (id_shift, id_akun, id_hari) FROM stdin;
\.
COPY public.shift_karyawan (id_shift, id_akun, id_hari) FROM '$$PATH$$/4896.dat';

--
-- Name: akun_id_akun_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.akun_id_akun_seq', 2, true);


--
-- Name: akun_role_id_role_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.akun_role_id_role_seq', 3, true);


--
-- Name: detail_hari_id_hari_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detail_hari_id_hari_seq', 1, false);


--
-- Name: histori_pembayaran_id_histori_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.histori_pembayaran_id_histori_pembayaran_seq', 1, false);


--
-- Name: histori_perubahan_status_id_status_perubahan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.histori_perubahan_status_id_status_perubahan_seq', 1, false);


--
-- Name: inventaris_id_barang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventaris_id_barang_seq', 1, false);


--
-- Name: layanan_id_layanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.layanan_id_layanan_seq', 1, false);


--
-- Name: metode_pembayaran_id_metode_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metode_pembayaran_id_metode_pembayaran_seq', 1, false);


--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pembayaran_id_pembayaran_seq', 1, false);


--
-- Name: presensi_id_presensi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presensi_id_presensi_seq', 1, false);


--
-- Name: reservasi_id_reservasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reservasi_id_reservasi_seq', 1, false);


--
-- Name: reservasi_status_id_status_reservasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reservasi_status_id_status_reservasi_seq', 1, false);


--
-- Name: shift_karyawan_id_shift_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shift_karyawan_id_shift_seq', 1, false);


--
-- Name: akun akun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.akun
    ADD CONSTRAINT akun_pkey PRIMARY KEY (id_akun);


--
-- Name: akun_role akun_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.akun_role
    ADD CONSTRAINT akun_role_pkey PRIMARY KEY (id_role);


--
-- Name: detail_hari detail_hari_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_hari
    ADD CONSTRAINT detail_hari_pkey PRIMARY KEY (id_hari);


--
-- Name: histori_pembayaran histori_pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_pembayaran
    ADD CONSTRAINT histori_pembayaran_pkey PRIMARY KEY (id_histori_pembayaran);


--
-- Name: histori_perubahan_status histori_perubahan_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_perubahan_status
    ADD CONSTRAINT histori_perubahan_status_pkey PRIMARY KEY (id_status_perubahan);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_barang);


--
-- Name: layanan layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.layanan
    ADD CONSTRAINT layanan_pkey PRIMARY KEY (id_layanan);


--
-- Name: metode_pembayaran metode_pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metode_pembayaran
    ADD CONSTRAINT metode_pembayaran_pkey PRIMARY KEY (id_metode_pembayaran);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: presensi presensi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensi
    ADD CONSTRAINT presensi_pkey PRIMARY KEY (id_presensi);


--
-- Name: reservasi reservasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi
    ADD CONSTRAINT reservasi_pkey PRIMARY KEY (id_reservasi);


--
-- Name: reservasi_status reservasi_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi_status
    ADD CONSTRAINT reservasi_status_pkey PRIMARY KEY (id_status_reservasi);


--
-- Name: shift_karyawan shift_karyawan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_karyawan
    ADD CONSTRAINT shift_karyawan_pkey PRIMARY KEY (id_shift);


--
-- Name: akun akun_akun_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.akun
    ADD CONSTRAINT akun_akun_role_id_fkey FOREIGN KEY (akun_role_id) REFERENCES public.akun_role(id_role);


--
-- Name: histori_pembayaran histori_pembayaran_id_reservasi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_pembayaran
    ADD CONSTRAINT histori_pembayaran_id_reservasi_fkey FOREIGN KEY (id_reservasi) REFERENCES public.reservasi(id_reservasi);


--
-- Name: histori_pembayaran histori_pembayaran_id_status_perubahan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.histori_pembayaran
    ADD CONSTRAINT histori_pembayaran_id_status_perubahan_fkey FOREIGN KEY (id_status_perubahan) REFERENCES public.histori_perubahan_status(id_status_perubahan);


--
-- Name: pembayaran pembayaran_id_metode_pembayaran_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran
    ADD CONSTRAINT pembayaran_id_metode_pembayaran_fkey FOREIGN KEY (id_metode_pembayaran) REFERENCES public.metode_pembayaran(id_metode_pembayaran);


--
-- Name: pembayaran pembayaran_id_reservasi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran
    ADD CONSTRAINT pembayaran_id_reservasi_fkey FOREIGN KEY (id_reservasi) REFERENCES public.reservasi(id_reservasi);


--
-- Name: presensi presensi_id_akun_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensi
    ADD CONSTRAINT presensi_id_akun_fkey FOREIGN KEY (id_akun) REFERENCES public.akun(id_akun);


--
-- Name: presensi presensi_id_shift_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensi
    ADD CONSTRAINT presensi_id_shift_fkey FOREIGN KEY (id_shift) REFERENCES public.shift_karyawan(id_shift);


--
-- Name: reservasi reservasi_id_akun_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi
    ADD CONSTRAINT reservasi_id_akun_fkey FOREIGN KEY (id_akun) REFERENCES public.akun(id_akun);


--
-- Name: reservasi reservasi_id_layanan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi
    ADD CONSTRAINT reservasi_id_layanan_fkey FOREIGN KEY (id_layanan) REFERENCES public.layanan(id_layanan);


--
-- Name: reservasi reservasi_id_status_reservasi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservasi
    ADD CONSTRAINT reservasi_id_status_reservasi_fkey FOREIGN KEY (id_status_reservasi) REFERENCES public.reservasi_status(id_status_reservasi);


--
-- Name: shift_karyawan shift_karyawan_id_akun_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_karyawan
    ADD CONSTRAINT shift_karyawan_id_akun_fkey FOREIGN KEY (id_akun) REFERENCES public.akun(id_akun);


--
-- Name: shift_karyawan shift_karyawan_id_hari_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift_karyawan
    ADD CONSTRAINT shift_karyawan_id_hari_fkey FOREIGN KEY (id_hari) REFERENCES public.detail_hari(id_hari);


--
-- PostgreSQL database dump complete
--

